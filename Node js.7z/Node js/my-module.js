// module.exports.foo = function(){
//     console.log(" foo called");
// }
// module.exports.MAGIC_NUMBER = Math.floor(Math.random() * 10);

function privateFunc(){
    console.log("Private function called");
}

function foo (){
    console.log(" Foo called")
}

function bar(){
    console.log("Bar Called")
}

module.exports={
    bar,
    foo
}