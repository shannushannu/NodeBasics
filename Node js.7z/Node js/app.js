// core modules:
//os
// const os = require("os");
// console.log("CPU's : "+ os.cpus().length);
// console.log("Arch : " + os.arch());
// console.log("Total Memory: " + os.totalmem());
// console.log("Free Memory: " + os.freemem());
// //fs
const fs = require("fs");
// const readstream = fs.createReadStream("./cool.txt");
// readstream.on("readable",() => {
//  let chunk = null;
//  while (null !== (chunk = readstream.read())){
//      console.log(chunk.toString());
//  }
// })
// const writestream = fs.createWriteStream("./new-cool.txt");
// readstream.pipe(writestream);

// const fileBuffer =fs.readFileSync("./cool.txt");
// console.log(fileBuffer.toString());
// console.log("Read operation completed");

// fs.readFile("./cool.txt",(err,data) => {
//     if(err) {
//         console.log(err);
//     }
//     console.log(data.toString())
//     fs.writeFile("./new-cool.txt",data,(err) => {
//         if(err) console.log(err);
//         console.log("Write successfully!")
//     })
// })
// console.log("Async Read completed");

// const http =  require("http");
// const server = http.createServer((request,response) => {
//     request.on("readable", () => {
//         let chunk = null;
//         while(null !=(chunk = request.read())){
//             console.log(chunk.toString());
//         }

//     })
//     response.write("Hello client!");
//     response.end();
// })
// server.listen(9090);
// console.log("server listening on port 9090");
const path = require("path");
const url = "http://www.example.com/public/index.html";
console.log(path.extname(url));
console.log(path.dirname(url));
console.log(path.basename(url));

//__filename || __dirname

console.log(__filename)
console.log(__dirname)



//External Module:

// const chalk = require("chalk");
// console.log(chalk.green("Helloworld"));
// console.log(chalk.inverse.green("Helloworld"));
// console.log(chalk.underline("Helloworld"));
// console.log(chalk.bold("Helloworld"));
// console.log(chalk.italic("Helloworld"));
// // Combine styled and normal strings
// console.log(chalk.blue('Hello') + ' World' + chalk.red('!'));
 
// // Compose multiple styles using the chainable API
// console.log(chalk.blue.bgRed.bold('Hello world!'));
 
// // Pass in multiple arguments
// console.log(chalk.blue('Hello', 'World!', 'Foo', 'bar', 'biz', 'baz'));
 
// // Nest styles
// console.log(chalk.red('Hello', chalk.underline.bgBlue('world') + '!'));
 
// // Nest styles of the same type even (color, underline, background)
// console.log(chalk.green(
//     'I am a green line ' +
//     chalk.blue.underline.bold('with a blue substring') +
//     ' that becomes green again!'
// ));
 const yargs = require("Yargs");
 console.log(process.argv)
 console.log("-------------------------")
 console.log(yargs.argv);

 yargs.command({
     command : "add",
     description : " To add new title",
     builder : {
         title : {
             type : String,
             demandOption : true,
             description : "New Title"
         },
         body : {
             type : String,
             demandOption : true,
             description : "New Body"
         }
     },
     handler : (argv) => {
         console.log("TITLE :",argv.title);
         console.log("BODY :",argv.body);
     }
 })
 yargs.parse();

//File Module:
// const myModule = require("./my-module");
// myModule.foo();
// myModule.bar();
