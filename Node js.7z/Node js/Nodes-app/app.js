const yargs = require("Yargs");

 yargs.command({
     command : "add",
     description : " To add new title",
     builder : {
         title : {
             type : String,
             demandOption : true,
             description : "New Title to add"
         },
         body : {
             type : String,
             demandOption : true,
             description : "New Body to add"
         },
         handler : argv => {
            console.log("Title :",argv.title)
     }
    }
 })


 //Read
 yargs.command({
    command : "read",
    description : " To read a note",
    builder : {
        title : {
            type : String,
            demandOption : true,
            description : "New read to add"
        }
        },
        handler : argv => {
            console.log("Title :",argv.title)
    }

})


//Write
yargs.command({
    command : "remove",
    description : " To add new title",
    builder : {
        title : {
            type : String,
            demandOption : true,
            description : "New Title to add"
        },
        body : {
            type : String,
            demandOption : true,
            description : "New Body to add"
        }
    
    }
})

//List
yargs.command({
    command : "list",
    description : " To read a node",
    handler : argv => {
        console.log("Title :",argv.title)
    
    }
})
yargs.parse();