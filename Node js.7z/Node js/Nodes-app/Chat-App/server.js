const express = require("express");
const app = express();
const server = require("http").createServer(app);
const io = require("socket.io")(server);
io.on("connection",client =>{
    console.log("New Client Connected");
    client.emit("acknowledge", {message : "Now Connected"});
    client.on("MsgToServer", ({chatterName,message}) => {
        console.log(chatterName +"says:" + message);
        name=chatterName;
        messages.push(message);
        client.emit("MsgToClient", {chatterName : "Me",message});
        client.broadcast.emit("MsgToClient", {chatterName, message});
    })
    client.on("disconnect", () =>{
        mongoutil.insertchat({name,messages});
        console.log("Disconnect");
    })
})

app.get("/", (req,res) => {
    res.sendFile(__dirname + "/public/client.html");
})


server.listen(9090, () => {
    console.log(" Socket Server Running on port 9090...");
})