const EventEmitter = require("events").EventEmitter;
const emitter = new EventEmitter();
//emit : to produce custom events
//on : to handle the triggered event
function handler(data){
    if(data){
        return console.log("Handler function called with "+ data.message);
    }
    console.log("Handler Function called!")
}
emitter.on("foo",handler);

emitter.on("foo", () => {
    console.log("Foo event fired!");
})
emitter.on("bar",handler);

 emitter.emit("foo");
 emmiter.emit("bar", {message : "Hello from Bar"});