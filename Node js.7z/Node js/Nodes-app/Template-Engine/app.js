const express = require("express");
// const hbs = require("hbs");
const ejs= require("ejs");
const app = express();
//app.set("view engine","hbs");
app.set("view engine","ejs");
app.set("views",__dirname+"/Template/views");

// hbs.registerPartials(__dirname+"/Template/Partials");

let username = "shabbukhaleel";
let age = 22;
app.get("/", (req,res) => {
    res.render("home",{username,age});

})

// app.get("/about",(req,res)=>{
//     res.render("about");
// })
// app.get("/home", (req,res) => {
//     res.render("home",{username,age});
// })
app.listen(9090,() =>{
    console.log("Server Listening to port 9090...");
})