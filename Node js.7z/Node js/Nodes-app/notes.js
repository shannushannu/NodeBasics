const fs = require("fs");

const loadNotes = () => {
    try{
    let notesBuffer = fs.readFileSync("notes.json");
    let notesString = notesBuffer.toString();
    return JSON.parse(notesString);
    }
    catch(e){
        return [];
    }

    }
    const saveNotes = (notes) => {
        fs.writeFileSync("notes.json",JSON.stringify(notes));
    }
    const addNote = (title,body) => {
        const allNotes = loadNotes();
        const duplicateNotes = allNotes.filter(note => note.title === title);
        if(duplicateNotes.length === 0)
        {
            allNotes.push({title,body});
            saveNotes(allNotes);
        }else{
            console.log(chalk.red(" Duplicate Title.Try Again!"))
        }
        }
    //REMOVE

    const removeNote = (title) => {
        const allNotes = loadNotes();
        const duplicateNotes = allNotes.filter(note => note.title !== title);
        if(duplicateNotes.length !== allNotes.length)
        {
            console.log(chalk.red(" Duplicate Title.Try Again!"))
         
        }else{
            saveNotes(duplicateNotes);
        }
    }
    //READ
    const readNote = (title) => {
    
        const allNotes= loadNotes();
        const duplicateNotes = allNotes.filter(note => note.title === title);
        if(duplicateNotes.length === 0)
        {
            console.log(chalk.red(" Note not Found.Try Again!"))
           
        }else{
            console.log(chalk.red(" Found Note"))
            console.log(chalk.grey(" **********************************************"))
            console.log(chalk.grey("Title :" + duplicateNotes[0].title))
            console.log(chalk.grey("Body :" + duplicateNotes[0].body))
        }
    }
//LIST
const listNote = (notes) => {
    const allNotes = loadNotes();
    const duplicateNotes=
