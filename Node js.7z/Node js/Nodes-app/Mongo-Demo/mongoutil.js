const mongodb = require("mongodb");
const client = mongodb.MongoClient;

const connect = () => {
    //LOCAL SERVER
    client.connect("mongodb://localhost:27017",{
        userNewUrlParser : true,
        useUnifiedTopology : true
    },(err,mongo)=> {
        if(err){
            process.exit(1);
            console.log(err);
        
    }
       console.log("Mongo Connected")
       _db = mongo.db("cg_db");
        // InsertDoc();
      //findDoc();
      delDoc();
      //updateDoc();

    })
}

    //CLOUD SERVER
//     client.connect("mongodb://scott:tiger123@ds029817.mlab.com.29817",{
//         newUrlParser : true,
//         useUnifiedTopology : true
// }, (err,mongo)=>{
//             console.log(err)
//             process.exit(1);

//             console.log("Mongo Connected");
//     })
 
 connect();
//Insert
const InsertDoc = () => {
    _db.collection("users").insert({
        "username" : "bar",
        "pass" : "bar123"
    },(err,result)=>{
        if(err) console.log(err)
        console.log("[RESULT]",result);
    })
}
//Find

const findDoc = () => {
 _db.collection("users").find().toArray((err,docs) => {
     if(err) console.log(err)
     console.log(docs);
 })
}
//Delete
const delDoc = () => {
    _db.collection("users").deleteOne({"username" : "foo"},(err,result)=>{
        if(err) console.log(err)
        console.log("Deleted Successfully");
    
    })
}
     //Update

      const updateDoc = () => {
         _db.collection("users").updateOne({"username" : "shabbu"},{"password" : "shabbu123"} , 
         (err,result)=>{
            if(err) console.log(err)
            console.log("Record Successfully");
        
        })
    }